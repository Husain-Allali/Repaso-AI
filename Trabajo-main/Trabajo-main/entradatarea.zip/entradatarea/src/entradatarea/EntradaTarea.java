/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package entradatarea;
import java.util.Scanner;
/**
 *
 * @author allal
 */
public class EntradaTarea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        String nombreTarea = "";

        // Bucle que solicita el nombre hasta que sea v�lido
        do {
            System.out.print("Introduzca el nombre de la tarea (Obligatorio): ");
            nombreTarea = sc.nextLine().trim();

            if (nombreTarea.isEmpty()) {
                System.out.println("Error: El t�tulo de la tarea no puede estar vac�o.");
            } else if (nombreTarea.length() < 3) {
                System.out.println("Error: El t�tulo debe tener al menos 3 caracteres.");
                nombreTarea = ""; // Reiniciamos para que el bucle contin�e
            }

        } while (nombreTarea.isEmpty());

        // Una vez sale del bucle, la tarea es v�lida
        System.out.println("\n Nombre de tarea registrado: " + nombreTarea);
        
        sc.close();
    }
    
}
