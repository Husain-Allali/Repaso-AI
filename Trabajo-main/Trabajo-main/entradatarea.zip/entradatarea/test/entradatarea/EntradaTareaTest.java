/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package entradatarea;
 
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import java.io.*;
import static org.junit.Assert.*;
 
public class EntradaTareaTest {
 
    private final InputStream originalIn = System.in;
    private final PrintStream originalOut = System.out;
    private ByteArrayOutputStream outContent;
 
    @Before
    public void setUp() {
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
    }
 
    @After
    public void tearDown() {
        System.setIn(originalIn);
        System.setOut(originalOut);
    }
 
    private void simularEntrada(String... lineas) {
        String input = String.join(System.lineSeparator(), lineas) + System.lineSeparator();
        System.setIn(new ByteArrayInputStream(input.getBytes()));
    }
 
    @Test
    public void testNombreValido() {
        simularEntrada("Comprar leche");
        EntradaTarea.main(new String[]{});
        assertTrue(outContent.toString().contains("Nombre de tarea registrado: Comprar leche"));
    }
 
    @Test
    public void testNombreVacio() {
        simularEntrada("", "Tarea v�lida");
        EntradaTarea.main(new String[]{});
        assertTrue(outContent.toString().contains("El t�tulo de la tarea no puede estar vac�o"));
    }
 
    @Test
    public void testNombreDemasiadoCorto() {
        simularEntrada("AB", "Tarea v�lida");
        EntradaTarea.main(new String[]{});
        assertTrue(outContent.toString().contains("El t�tulo debe tener al menos 3 caracteres"));
    }
}
 
